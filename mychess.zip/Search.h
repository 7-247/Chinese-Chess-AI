#include "Position.h"
int SearchMain(PositionStruct& pos, int gotime);
